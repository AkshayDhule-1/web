package dao;

public class TicketSeat {

}
