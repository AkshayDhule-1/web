package dao;

public class TicketSeatDAO {

}
