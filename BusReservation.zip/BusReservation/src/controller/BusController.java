package controller;
package com.java.controller;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import service.AvailableBuses;
import service.BusService;
import service.BusServiceImplementation;

@GET()
@Path("/busService")
public class BusController {
		
	BusService busService = new BusServiceImplementation();
	
	
	@GET()   @Produces(MediaType.APPLICATION_JSON)
	@Path("/showbuses")
	public List<AvailableBuses> showAvailableBuses(){
		
//		String htmlResponse = "<html><body><h1>Available Buses</h1><p>Bus 1 from Source to Destination</p><p>Bus 2 from Source to Destination</p></body></html>";
//	    return Response.ok(htmlResponse).build();
		
		return busService.showAvailableBuses(src, dest, date);
	}
	
}
