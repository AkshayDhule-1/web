package com.java.testing;


import java.sql.Date;
import java.sql.Time;

import com.java.dao.Admin;
import com.java.dao.AdminDAO;
import com.java.dao.AdminDAOImplementation;
import com.java.dao.Buses;
import com.java.dao.BusesDAO;
import com.java.dao.BusesDAOImplementation;
import com.java.dao.Route;
import com.java.dao.RouteDAO;
import com.java.dao.RouteDAOImplementation;
import com.java.dao.Ticket;
import com.java.dao.TicketDAO;
import com.java.dao.TicketDAOImplementation;
import com.java.dao.TravelTime;
import com.java.dao.TravelTimeDAO;
import com.java.dao.TravelTimeDAOImplementation;

public class Test {
	public static void main(String[] args) {
		
		

//		TravelTimeDAO travelDAO = new TravelTimeDAOImplementation();
//		TravelTime tt = new TravelTime();
//		
//		tt.setTime(Time.valueOf("03:00:00"));
//		tt.setBusId(103);
//		tt.setRouteId(2);
//		travelDAO.insertTravel(tt);
//		travelDAO.deleteTravel(Time.valueOf("03:00:00"));
//		travelDAO.selectTravels();
		
		
/////////------------------------------------------------------------
//		TicketDAO ticketDAO = new TicketDAOImplementation();
//		Ticket ticket = new Ticket();
//		
//		ticketDAO.selectTickets();
		
//		 3 |    3 | 10:45:00 |   103 | 2023-08-05  | conform | 2023-08-12 |         3 |        600 
		
		
//		ticket.setTid(3);
//		ticket.setUid(3);
//		ticket.setTime(Time.valueOf("10:45:00"));
//		ticket.setBusId(103);
//		ticket.setJourneyDate(Date.valueOf("2023-08-05"));
//		ticket.setBookedDate(Date.valueOf("2023-08-12"));
////		ticket.setJourneyDate(java.sql.Date.valueOf("2023-08-09")); // Use java.sql.Date
////		ticket.setBookedDate(java.sql.Date.valueOf("2023-08-06")); // Use java.sq
//		ticket.setStatus("Conform");
//		ticket.setNoOfSeats(3);
//		ticket.setAmountPaid(600.0f);
//		
//		
//		ticketDAO.insertTicket(ticket);
//		
//		ticketDAO.selectTickets();
/////////------------------------------------------------------------		
		
//		BusesDAO busDAO = new BusesDAOImplementation();
//		Buses bus = new Buses();
//		
//		bus.setBusId(105);
//		bus.setBusNumber("MH29 AJ9834");
//		bus.setBusType("NON AC");
//		bus.setTravelAgency("KHURANA");
//		bus.setAvailableSeats(29);
//		bus.setTotalSeats(40);
//		bus.setFare(400.0f);
//		
////		busDAO.insertBus(bus);
//		busDAO.selectBuses();
//		
//		
//		
///////////------------------------------------------------------------	\
//		
//		AdminDAO adDAO = new AdminDAOImplementation();
//		Admin admin = new Admin();
//		admin.setAdminPassword("admin");
//		adDAO.insertAdmin(admin);
//		
//		adDAO.selectAdmin();
///////////------------------------------------------------------------	
		
//		RouteDAO routeDAO = new RouteDAOImplementation();
//		Route route = new Route();
//		
//		routeDAO.selectRoutes();
//		route.setRid(5);
//		route.setSrc("Nagpur");
//		route.setDest("Mumbai");
//		route.setDistance(500.0f);
//		route.setJourneyTime(Time.valueOf("07:15:00"));
//		
//		routeDAO.insertRoute(route);
//		routeDAO.selectRoutes();
//		
/////////------------------------------------------------------------	


	
		
		
		
	}
}
